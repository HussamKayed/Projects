import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Write a description of class GUITestClass here.
 *
 * @author Hussam Kayed
 * @version 07/06/2020
 */
public class GUI implements ActionListener {
    //go west, go south, go east, go north, pick item, drop item, back, help
    private JFrame frame;
    private JPanel mainPanel;
    private JPanel inputPanel;
    private JPanel imagePanel;
    private JPanel outputPanel;
    private JPanel buttonsPanel;
    private JLabel inputLabel;
    private JLabel imageLabel;
    private JButton okayButton;
    private JTextField inputField;
    private JTextArea outputField;
    private JScrollPane outputView;
    private JScrollBar scroll;
    private JButton okay;
    private ImageIcon image;
    private Parser parser;
    private Game game;
    private Room currentRoom;

    public GUI() {
        frame = new JFrame();
        inputPanel = new JPanel();
        inputLabel = new JLabel("Input Field");
        mainPanel = new JPanel();
        outputPanel = new JPanel();
        imagePanel = new JPanel();
        buttonsPanel = new JPanel();
        okayButton = new JButton();
        inputField = new JTextField(30);
        outputField = new JTextArea(50,50);
        //outputView = new JScrollPane(outputField, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
       //outputView.getViewport().add(outputField);
        //scroll = new JScrollBar();
        okay = new JButton("okay");
        game = new Game();
        image = game.getCurrentRoom().getImage();
        imageLabel = new JLabel(image);
        launchTestGUI();
        outputField.setText(printWelcome());
    }

    public void launchTestGUI() {
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //formatting panels
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setPreferredSize(new Dimension(700, 700));


        Box outputBox = Box.createHorizontalBox();
        outputBox.add(new JLabel("output", JLabel.LEFT));
        outputBox.add(Box.createGlue());
        //outputField.add(scroll);
        //outputBox.add(outputField);

        inputPanel.setLayout(new FlowLayout());
        inputPanel.setBorder(BorderFactory.createLineBorder(Color.white, 1));
        buttonsPanel.setLayout(new FlowLayout());
        buttonsPanel.setBorder(BorderFactory.createLineBorder(Color.white, 1));
        imagePanel.setLayout(new FlowLayout());
        imagePanel.setBorder(BorderFactory.createLineBorder(Color.white, 1));

        //input panel elements
        inputPanel.add(inputLabel);
        inputPanel.add(inputField);

        //buttons panel elements
        buttonsPanel.add(okay);
        okay.addActionListener(this);

        //output panel elements and specific properties

        outputPanel.setPreferredSize(new Dimension(200, 200));
        //outputPanel.add(outputView, BorderLayout.CENTER);


        //image panel elements
        imagePanel.add(imageLabel);


        //adding everything to the main panel
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(buttonsPanel, BorderLayout.NORTH);
        mainPanel.add(imagePanel,BorderLayout.CENTER);
        mainPanel.add(new JScrollPane(outputField),BorderLayout.SOUTH);
        mainPanel.add(outputBox, BorderLayout.SOUTH);

        // finalizing the frame
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.setTitle("JOKER'S GREAT ESCAPE");
        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       /*String currentOutputFieldText = outputField.getText()+inputField.getText()+"\n";
       outputField.setText(currentOutputFieldText);
       inputField.setText("");*/
        String currentOutputFieldText = outputField.getText() + inputField.getText() + "\n";
        String currentInput = inputField.getText();
        parser = new Parser(currentInput);
        Command command = parser.getCommand();
        String commandWord = command.getCommandWord();
        if (commandWord.equals("go")) {
            currentOutputFieldText += game.goRoom(command) + "\n";
        } else if (commandWord.equals("pick")) {
            currentOutputFieldText += game.pickItem(command) + "\n";
        } else if (commandWord.equals("back")) {
            currentOutputFieldText += game.back(command) + "\n";
        } else if (commandWord.equals("drop")) {
            currentOutputFieldText += game.dropItem(command) + "\n";
        } else if (commandWord.equals("help")) {
            currentOutputFieldText += game.printHelp() + parser.showCommands() + "\n";
        } else if (commandWord.equals("inventory")) {
            currentOutputFieldText += game.playerInventory() + "\n";
        } else if (commandWord.equals("quit")) {
            currentOutputFieldText += game.quit(command) + "\n";
            inputField.setEditable(false);
        } else if(commandWord.equals("I don't know what you mean")){
            currentOutputFieldText += "I don't know what this means\n";
        }
        image = game.getCurrentRoom().getImage();
        
        imageLabel = new JLabel(image);
        imagePanel.removeAll();
        imagePanel.add(imageLabel);
        imagePanel.revalidate();
        imagePanel.repaint();
        
        if (currentRoom == game.getCurrentRoom()) {
            currentOutputFieldText += game.winConditionCheck() + "\n";
            inputField.setEditable(false);
        }
        outputField.setText(currentOutputFieldText);
        inputField.setText("");
    }

    public String printWelcome() {
        return "Welcome to the Arkham Asylum!\n"
                + "Arkham Asylum, incredibly interesting adventure game.\nYour goal is to collect item which will help you in escaping\n"
                + "You have to collect 3 items\n" +
                "Two items are of weapons and one is to diguise yourself to fool the guards\n"
                + "Good Luck.\n"
                + "Type 'help' if you need help.\n";

    }


}
