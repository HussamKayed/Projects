import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

/**
 * This is the main class of the "Joker's Great Escape" game. This is a very interesting game
 * which envolves the escape of the joker from an asylum in gotham city called "The Arkham Asylum"
 * The game has items that will help you escape from the Asylum but remember, when you are choosing
 * the items, choose wisely because you are only allowed to carry around max 3 items and having
 * the suitable three items is your winning condition in this game
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 *  
 *  
 * 
 * @author  Hussam Kayed
 * @version 07/06/2020
 */

public class Game 
{
    private Parser parser;
    private Room currentRoom;
    private Inventory bag;
    private Stack<Back> states = new Stack();

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        createRooms();
        bag = new Inventory();
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room jokerCell, isolationCell,mrFreezerCell,ratLab,hallWay,kitchen,storageRoom,diningHall,therapyCenter,watchRoom,secretRoom,finalRoom;
        Item lockPickTool, gun, claw, rope, mrFreezerGun, guardOutFit, watchRoomKey;
        //ImageIcon image = new ImageIcon(getClass().getResource("./joker'sCell.jpg"));
        // create the rooms
        jokerCell = new Room("Joker's cell you start here in your cell");
        //}
        jokerCell.setImage(new ImageIcon(getClass().getResource("./joker's cell.jpg")));

        isolationCell = new Room("isolation Cell punishment for bad behavior");
        isolationCell.setImage(new ImageIcon(getClass().getResource("./isolation cell.jpg")));
        mrFreezerCell = new Room("Mr. Freezer's room, your mate's room");
        mrFreezerCell.setImage(new ImageIcon(getClass().getResource("./freeze's cell.png")));
        ratLab= new Room("RatLab you are trapped forever");
        ratLab.setImage(new ImageIcon(getClass().getResource("./rat lab room.jpg")));
        hallWay = new Room("Hallway way to other rooms");
        hallWay.setImage(new ImageIcon(getClass().getResource("./hallway.jpg")));
        kitchen = new Room("Kitchen. food is cooked here, your kind of place?");
        kitchen.setImage(new ImageIcon(getClass().getResource("./kitchen.jpg")));
        storageRoom = new Room("Storage Room.you can find useful items here");
        storageRoom.setImage(new ImageIcon(getClass().getResource("./storage room.jpg")));
        diningHall = new Room("Dinner Hall. you can eat here enjoy!");
        diningHall.setImage(new ImageIcon(getClass().getResource("./asylum dinning hall.jpg")));
        therapyCenter = new Room("Therapy Center. patient's get therapy here");
        therapyCenter.setImage(new ImageIcon(getClass().getResource("./therapy room.jpg")));
        watchRoom = new Room("Watch room. guard's are watching becareful");
        watchRoom.setImage(new ImageIcon(getClass().getResource("./watch room.jpg")));
        secretRoom = new Room("Secret room. no one knows what goes on here");
        secretRoom.setImage(new ImageIcon(getClass().getResource("./secret Room.png")));
        finalRoom = new Room("Escape");
        finalRoom.setImage(new ImageIcon(getClass().getResource("./escape room.jpg")));
        // create the items
        lockPickTool = new Item("LockPick");
        gun = new Item("Gun");
        claw = new Item("Claw");
        rope = new Item("Rope");
        mrFreezerGun = new Item("Freezergun");
        guardOutFit = new Item("Guardoutfit");
        watchRoomKey = new Item("Watchroomkey");

        //putting items in room
        jokerCell.addItem(lockPickTool);
        watchRoom.addItem(gun);
        watchRoom.addItem(claw);
        storageRoom.addItem(rope);
        storageRoom.addItem(guardOutFit);
        mrFreezerCell.addItem(mrFreezerGun);
        kitchen.addItem(watchRoomKey);

        // initialise room exits
        jokerCell.setExit("south", hallWay);
        isolationCell.setExit("east", mrFreezerCell);
        isolationCell.setExit("north", ratLab);
        mrFreezerCell.setExit("west", isolationCell);
        mrFreezerCell.setExit("south", kitchen);
        hallWay.setExit("north", jokerCell);
        hallWay.setExit("east", kitchen);
        hallWay.setExit("south", diningHall);
        kitchen.setExit("north",mrFreezerCell);
        kitchen.setExit("west",hallWay);
        kitchen.setExit("south",therapyCenter);
        storageRoom.setExit("east", diningHall);
        storageRoom.setExit("south", watchRoom);
        diningHall.setExit("north",hallWay);
        diningHall.setExit("west",storageRoom);
        therapyCenter.setExit("north", kitchen);
        watchRoom.setExit("north",storageRoom);
        watchRoom.setExit("east", secretRoom);
        secretRoom.setExit("west", watchRoom);
        secretRoom.setExit("south", finalRoom);

        currentRoom = jokerCell;  // start game joker's cell
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
//    public void play()
//    {
//        printWelcome();
//
//        // Enter the main command loop.  Here we repeatedly read commands and
//        // execute them until the game is over.
//
//        boolean finished = false;
//        while (! finished) {
//            Command command = parser.getCommand();
//            finished = processCommand(command);
//        }
//        System.out.println("Thank you for playing.  Good bye.");
//    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to the Arkham Asylum!");
        System.out.println("Arkham Asylum, incredibly interesting adventure game.");
        System.out.println("Your goal is to collect item which will help you in escaping");
        System.out.println("You have to collect 3 items");
        System.out.println("Two items are of weapons and one is to diguise yourself to fool the guards");
        System.out.println("Good Luck.");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
        currentRoom.itemsInRoom();
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
//    private boolean processCommand(Command command)
//    {
//        boolean wantToQuit = false;
//
//        if(command.isUnknown()) {
//            System.out.println("I don't know what you mean...");
//            return false;
//        }
//
//        String commandWord = command.getCommandWord();
//        if (commandWord.equals("help")) {
//            printHelp();
//        }
//        else if (commandWord.equals("go")) {
//            wantToQuit = goRoom(command);
//        }
//        else if (commandWord.equals("pick")) {
//            pickItem(command);
//        }
//        else if (commandWord.equals("drop")) {
//            dropItem(command);
//        }
//        else if (commandWord.equals("inventory")) {
//            playerInventory();
//        }
//        else if (commandWord.equals("back")){
//            back(command);
//        }
//        else if (commandWord.equals("quit")) {
//            wantToQuit = quit(command);
//        }
//
//        // else command not recognised.
//        return wantToQuit;
//    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
   public String printHelp()
    {
        return "You are Joker. You are trapped. You try to escape\nthe Asylum.\nour command words are:\n";

    }

    /** 
     * Try to in to one direction. If there is an exit, enter the new
     * room, otherwise print an error message.
     */
    public String goRoom(Command command)
    {
        String endGame = "";
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            endGame ="Go where?";
            return endGame;
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            endGame = "There is no door!";
        }
        else if(nextRoom.getShortDescription().equals("Escape")) //checks if we are in the final room
        {
            winConditionCheck();
            endGame = "won";
            return endGame;
        }
        else
        {
            Back back = new Back(currentRoom,bag.getStateItems());
            states.push(back);
            currentRoom = nextRoom;
            currentRoom.itemsInRoom();
            endGame = currentRoom.getLongDescription();
        }
        return endGame;
    }

    /**
     * Method winConditionCheck
     * checks if we have necessary items to win or not, if yes player wins the game if not , lost
     */
   public String winConditionCheck()
    {
        String hasWon = "";
        Win win = new Win();
        Collections.sort(bag.getInventory());
        if(win.compareArrayList(bag.getInventory()))
        {
            hasWon = "You won congratulations";
        }
        else
        {
            hasWon = "You lost";
        }
    return hasWon;
    }

    /**
     * Method pickItem try to pick up an item from the room to player's inventory
     *
     * @param command Command give us the item we need to pick up
     */
    public String pickItem(Command command)
    {
        String itemPicked = "";
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to pick...
            itemPicked = "pick what?";
            return itemPicked;
        }

        if(bag.getSize() >=3)
        {
            itemPicked = "You have reached maximum limit to store items, to pick up this item, remove an existing item from your inventory." +currentRoom.itemsInRoom()+currentRoom.getLongDescription();
        }
        else
        {
            String item = command.getSecondWord();
            bag.addItem(item);
            currentRoom.removeItem(item);
            itemPicked = currentRoom.itemsInRoom()+currentRoom.getLongDescription();
        }
        return itemPicked;
    }

    /**
     * Method dropItem try to drop an item from the player's inventory to the room 
     *
     * @param command Command give us the item we need to drop
     */
    public String dropItem(Command command)
    {
        String droppedItemState = "";
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to drop...
            droppedItemState="drop what?";
            return droppedItemState;
        }

        if(currentRoom.getSize() >=3)
        {
            droppedItemState ="Room already has at maximum capacity, you cannot drop this item here."+
            currentRoom.itemsInRoom()+currentRoom.getLongDescription();

        }
        else
        {
            String item = command.getSecondWord();
            bag.removeItem(item);

            currentRoom.addItemByName(item);
            droppedItemState=currentRoom.itemsInRoom()+currentRoom.getLongDescription();
        }
        return droppedItemState;
    }

    /**
     * Method playerInventory
     * prints the items found in player's inventory
     */
    public String playerInventory()
    {
       return bag.playerInventory()+"\n"+currentRoom.itemsInRoom()+"\n"+currentRoom.getLongDescription();
    }

    /**
     * Method back Take the player to it's previous state of room and item
     *
     * @param command A parameter
     */
    public String back(Command command)
    {
        String currentState = "";
        if(command.hasSecondWord()) {
            return "back what?";
        }

        if(states.empty()) // checks if the stack is empty 
        {
            return "Can't go back, you just started.";
        }
        else
        {
            Back previousState = states.pop();
            if(bag.getSize() > previousState.getPrevSize())
            {
                for(int i = bag.getSize() ; i> previousState.getPrevSize() ; i--)
                {
                    currentRoom.addItem(new Item(bag.getByindex(i-1)));
                }
            }
            else if(bag.getSize() < previousState.getPrevSize())
            {
                for(int i= previousState.getPrevSize(); i > bag.getSize()  ; i--)
                {
                    currentRoom.removeItem(bag.getByindex(i-1));
                }
            }

            currentRoom = previousState.getRoom(); 
            bag.previousItems(previousState.getItemsList());
            currentState = currentRoom.itemsInRoom()+currentRoom.getLongDescription();
        }
        return currentState;
    }

    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    public String quit(Command command)
    {
        if(command.hasSecondWord()) {
            return"Quit what?";

        }
        else {
            return "thanks for playing and goodbye";  // signal that we want to quit
        }
    }

    public Room getCurrentRoom()
    {
        return this.currentRoom;
    }


}
